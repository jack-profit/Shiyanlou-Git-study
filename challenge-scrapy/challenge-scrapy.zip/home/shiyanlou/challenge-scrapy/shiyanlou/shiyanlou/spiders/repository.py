# -*- coding: utf-8 -*-
import scrapy
from shiyanlou.items import RepositoryItem

class RepositorySpider(scrapy.Spider):
    name = 'repository'
    allowed_domains = ['github.com']
    start_urls = [
            'https://github.com/shiyanlou?tab=repositories',
            'https://github.com/shiyanlou?after=Y3Vyc29yOnYyOpK0MjAxNy0wNi0wN1QwMDowNjo1M1rOBZKSjQ%3D%3D&tab=repositories',
            'https://github.com/shiyanlou?after=Y3Vyc29yOnYyOpK0MjAxNS0wMS0zMVQxMjoyMDowMlrOAcx4tQ%3D%3D&tab=repositories',
            'https://github.com/shiyanlou?after=Y3Vyc29yOnYyOpK0MjAxNC0xMi0wM1QxNjoxNzo1M1rOAaQp7g%3D%3D&tab=repositories',
            'https://github.com/shiyanlou?after=Y3Vyc29yOnYyOpK0MjAxNC0wOS0xNlQwMjowNjowM1rOAW91HQ%3D%3D&tab=repositories'
            ]

    def parse(self, response):
        for re in response.css('div#user-repositories-list ul'):
            item = RepositoryItem({
                'name': re.css('h3 a::text').extract_first().strip(),
                'update_time': re.css('relative-time::attr(datetime)').extract_first()
                })
            yield item

